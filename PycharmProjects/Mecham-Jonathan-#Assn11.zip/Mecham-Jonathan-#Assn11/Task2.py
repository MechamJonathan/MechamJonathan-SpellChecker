#Jonathan Mecham
#Comp Science 1400
# program that takes input from user and outputs bank statement




from account import main

main()