print("my name is Jonathan Mecham"
      " My computer is ready to go!!")