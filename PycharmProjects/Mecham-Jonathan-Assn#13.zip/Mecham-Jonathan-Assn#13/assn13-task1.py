#Jonathan Mecham
#Comp science 1400
#program takes the sides of two polygons and performs various operations on them.

from polygon import Polygon

def main():
    p = Polygon()

    p.__add__()
    p.__sub__()
    p.__lt__()
    p.__gt__()
    p.__eq__()
    p.__len__()
    p.__str__()





main()