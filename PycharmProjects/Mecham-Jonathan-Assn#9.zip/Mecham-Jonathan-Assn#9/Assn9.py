
from chessboard import *

main()


